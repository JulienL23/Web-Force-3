			</div>
        </section>
        <footer>
			<div class="conteneur">    
				<?= date('Y') ?> - Tous droits reserv�s.
			</div>
        </footer>
    </body>
</html>