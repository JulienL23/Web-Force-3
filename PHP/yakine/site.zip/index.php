﻿<?php
require_once('inc/init.inc.php');
require_once('inc/header.inc.php');
?>
<!--  Contenu HTML -->
<h1>Accueil</h1>






<?php 
require_once('inc/footer.inc.php');
?>